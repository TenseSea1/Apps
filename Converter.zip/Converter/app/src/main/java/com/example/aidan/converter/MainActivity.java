package com.example.aidan.converter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.Selection;
import android.widget.EditText;
import android.text.TextWatcher;
import android.widget.TextView;
import android.widget.Toast;

import static android.widget.TextView.BufferType.EDITABLE;///////////////////////////

public class MainActivity extends AppCompatActivity {
    private String oldB = "";
    private String oldD = "";
    private String oldH = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText b = findViewById(R.id.editText);
        final EditText d = findViewById(R.id.editText2);
        final EditText h = findViewById(R.id.editText3);

        b.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int n = 0;
                int[] is = new int[count];

                if (!oldB.contentEquals(s)) {
                    for (int i = start; i < start + count; i++) {
                        if(!"01".contains(s.toString().substring(i, i + 1))) {
                            is[n] = i;
                            n++;
                         }
                    }
                    for(int j = 0; j < n; j++)
                        Toast.makeText(MainActivity.this, "\"" + s.toString().substring(is[j], is[j] + 1) +
                                "\" is not a valid character for this base.", Toast.LENGTH_LONG).show();
                }
                Selection.setSelection(b.getText(), start + count);
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!oldB.equals(s.toString())) {
                    String temp = s.toString();

                    for (int i = 0; i < temp.length(); i++) {
                        if (!"01".contains(temp.substring(i, i + 1))) {
                            temp = temp.substring(0, i) + ((i < temp.length() - 1) ? temp.substring(i + 1) : "");
                            i--;
                        }
                    }
                    oldB = temp;
                    b.setText(temp, TextView.BufferType.EDITABLE);
                    if (!oldD.equals(convert(temp, 2, 10)))
                        d.setText(convert(temp, 2, 10), TextView.BufferType.EDITABLE);
                }
            }
        });

        d.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                int n = 0;
                int[] is = new int[count];

                if (!oldD.contentEquals(s)) {
                    for (int i = start; i < start + count; i++) {
                        if(!"0123456789".contains(s.toString().substring(i, i + 1))) {
                            is[n] = i;
                            n++;
                        }
                    }
                    for(int j = 0; j < n; j++)
                        Toast.makeText(MainActivity.this, "\"" + s.toString().substring(is[j], is[j] + 1) +
                                "\" is not a valid character for this base.", Toast.LENGTH_LONG).show();
                }
                Selection.setSelection(d.getText(), start + count);
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!oldD.equals(s.toString())) {
                    String temp = s.toString();

                    for (int i = 0; i < temp.length(); i++) {
                        if (!"0123456789".contains(temp.substring(i, i + 1))) {
                            temp = temp.substring(0, i) + ((i < temp.length() - 1) ? temp.substring(i + 1) : "");
                            i--;
                        }
                    }
                    oldD = temp;
                    d.setText(temp, TextView.BufferType.EDITABLE);
                    if (!oldH.equals(convert(temp, 10, 16)))
                        h.setText(convert(temp, 10, 16), TextView.BufferType.EDITABLE);
                }
            }
        });

        h.addTextChangedListener(new TextWatcher() {

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                int n = 0;
                int[] is = new int[count];

                if (!oldH.contentEquals(s)) {
                    for (int i = start; i < start + count; i++) {
                        if(!"0123456789ABCDEF".contains(s.toString().substring(i, i + 1).toUpperCase())) {
                            is[n] = i;
                            n++;
                        }
                    }
                    for(int j = 0; j < n; j++)
                        Toast.makeText(MainActivity.this, "\"" + s.toString().substring(is[j], is[j] + 1) +
                                "\" is not a valid character for this base.", Toast.LENGTH_LONG).show();
                }
                Selection.setSelection(h.getText(), start + count);
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (!oldH.equals(s.toString())) {
                    String temp = s.toString();

                    for (int i = 0; i < temp.length(); i++) {
                        if (!"0123456789ABCDEF".contains(temp.substring(i, i + 1).toUpperCase())) {
                            temp = temp.substring(0, i) + ((i < temp.length() - 1) ? temp.substring(i + 1) : "");
                            i--;
                        }
                    }
                    oldH = temp;
                    h.setText(temp, TextView.BufferType.EDITABLE);
                    if (!oldB.equals(convert(temp, 16, 2)))
                        b.setText(convert(temp, 16, 2), TextView.BufferType.EDITABLE);
                }
            }
        });
    }

    private static String convert(String input, int baseIn, int baseOut) {
        if(input.equals(""))
            return "";
        boolean zero = true;
        for(int i = 0; i < input.length(); i++) {
            if(!input.substring(i, i + 1).equals("0"))
                zero = false;
        }
        if(zero)
            return "0";
        int dec = 0;
        //to decimal
        for(int i = input.length() - 1; i >= 0; i--) {
            dec += Math.pow(baseIn, input.length() - i - 1) * alphanumToNum(input.substring(i, i + 1));
        }
        String result = "";
        //to base2
        //if base2 = 1
        if(baseOut == 1) {
            for(int a = 0; a < dec; a++) {
                result += "1";
            }
            return result;
        }
        //base2 != 1
        int k;
        for (k = 0; (Math.pow(baseOut, k) <= dec); k++) { }
        k--;
        while(k >= 0) {
            int n;
            for(n = 0; dec >= n * Math.pow(baseOut, k); n++) { }
            n--;
            result += numToAlphanum(n);
            dec -= n * Math.pow(baseOut, k);
            k--;
        }
        return result;
    }

    private static int alphanumToNum(String alpha) {
        int ascii = (int)alpha.toUpperCase().charAt(0);
        return ascii - 48 - (ascii > 64 ? 7 : 0);
    }

    private static String numToAlphanum(int n) {
        if(n < 10) return "" + n;
        if(n < 36) return String.valueOf((char) (n + 55));
        return "Bases greater than 35 are not supported!\n\n\n\n\n\n\n\n\n\n\n\n\n\n";
    }
}